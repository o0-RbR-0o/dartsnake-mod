Raumffisch\[NoCanvas\] (Dartsnake-mod)
==============

Raumffisch\[NoCanvas\] is a fork of Dartsnake by Nane Kratzke which implements a new game concept (Space(Fish) Shooter) while using the basic game grid and the MVC design of Dartsnake.
The project itself is a semester project for the class "Webtechnologien" at the University of Applied Sciences Lübeck.


Dartsnake and the original readme file can be found [here][dartsnake].

[dartsnake]: https://github.com/nkratzke/dartsnake
