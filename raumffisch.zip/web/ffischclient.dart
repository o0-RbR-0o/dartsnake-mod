import 'package:raumffisch/raumffisch.dart';

main() => new GameController();